package com.foodorder.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cust_address")
public class Address {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long addrId;
	private String houseNo;
	private String area;
	private String city;
	
	public Address()
	{
		super();
	}
	public Address(String houseNo, String area, String city) {
		super();
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
	}
	public Long getAddrId() {
		return addrId;
	}
	public String getHouseNo() {
		return houseNo;
	}
	
	public String getArea() {
		return area;
	}
	
	public String getCity() {
		return city;
	}
	
	
}
