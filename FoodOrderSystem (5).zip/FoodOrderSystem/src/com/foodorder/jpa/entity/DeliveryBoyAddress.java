package com.foodorder.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dboy_address")
public class DeliveryBoyAddress {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long addrId;
	private String houseNo;
	private String area;
	private String city;
	public DeliveryBoyAddress() {
		super();
	}
	public DeliveryBoyAddress(Long addrId, String houseNo, String area, String city) {
		super();
		this.addrId = addrId;
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
	}
	public Long getAddrId() {
		return addrId;
	}
	public void setAddrId(Long addrId) {
		this.addrId = addrId;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
