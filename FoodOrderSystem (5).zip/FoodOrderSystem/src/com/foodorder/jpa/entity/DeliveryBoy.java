package com.foodorder.jpa.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="deliveryboy")

public class DeliveryBoy {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long dId;
	private String dName;
	private String dPhone;
	private String dEmail;
	private String dUserName;
	private String dPassword;
	@OneToOne(cascade = CascadeType.PERSIST)  
	private DeliveryBoyAddress dAdd;
	
	public DeliveryBoy() {
		super();
		
	}
	public DeliveryBoy(Long dId, String dName, String dPhone, String dEmail, String dUserName, String dPassword,
			DeliveryBoyAddress dAdd) {
		super();
		this.dId = dId;
		this.dName = dName;
		this.dPhone = dPhone;
		this.dEmail = dEmail;
		this.dUserName = dUserName;
		this.dPassword = dPassword;
		this.dAdd = dAdd;
	}
	public Long getdId() {
		return dId;
	}
	public void setdId(Long dId) {
		this.dId = dId;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public String getdPhone() {
		return dPhone;
	}
	public void setdPhone(String dPhone) {
		this.dPhone = dPhone;
	}
	public String getdEmail() {
		return dEmail;
	}
	public void setdEmail(String dEmail) {
		this.dEmail = dEmail;
	}
	public String getdUserName() {
		return dUserName;
	}
	public void setdUserName(String dUserName) {
		this.dUserName = dUserName;
	}
	public String getdPassword() {
		return dPassword;
	}
	public void setdPassword(String dPassword) {
		this.dPassword = dPassword;
	}
	public DeliveryBoyAddress getdAdd() {
		return dAdd;
	}
	public void setdAdd(DeliveryBoyAddress dAdd) {
		this.dAdd = dAdd;
	}
	
}