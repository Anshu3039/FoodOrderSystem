package com.foodorder.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orderfooditem")
public class OrderFoodItem {
	@Id
	private Long itemId;
	private int itemQty;
	public OrderFoodItem() {
		super();
		
	}
	public OrderFoodItem(Long itemId, int itemQty) {
		super();
		this.itemId = itemId;
		this.itemQty = itemQty;
	}
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public int getItemQty() {
		return itemQty;
	}
	public void setItemQty(int itemQty) {
		this.itemQty = itemQty;
	}
}