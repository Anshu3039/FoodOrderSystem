package com.foodorder.jpa.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="order")
public class Order 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long ordId;
	private String custId;
	private String ordDate;
	private String ordStatus;
	private String ordPmntStatus;
	private Long orddbId;
	private int ordTotalBill;
	
	@OneToMany(targetEntity=OrderFoodItem.class)
	private List ordFoodItem;

	public Long getOrdId() {
		return ordId;
	}

	public void setOrdId(Long ordId) {
		this.ordId = ordId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getOrdDate() {
		return ordDate;
	}

	public void setOrdDate(String ordDate) {
		this.ordDate = ordDate;
	}

	public String getOrdStatus() {
		return ordStatus;
	}

	public void setOrdStatus(String ordStatus) {
		this.ordStatus = ordStatus;
	}

	public String getOrdPmntStatus() {
		return ordPmntStatus;
	}

	public void setOrdPmntStatus(String ordPmntStatus) {
		this.ordPmntStatus = ordPmntStatus;
	}

	public Long getOrddbId() {
		return orddbId;
	}

	public void setOrddbId(Long orddbId) {
		this.orddbId = orddbId;
	}

	public int getOrdTotalBill() {
		return ordTotalBill;
	}

	public void setOrdTotalBill(int total_bill) {
		this.ordTotalBill = total_bill;
	}

	public List getOrdFoodItem() {
		return ordFoodItem;
	}

	public void setOrdFoodItem(List ordFoodItem) {
		this.ordFoodItem = ordFoodItem;
	}
	
}