package com.foodorder.jpa.app;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.foodorder.jpa.controller.CustomerController;
import com.foodorder.jpa.controller.DeliveryController;
import com.foodorder.jpa.controller.FoodItemController;
import com.foodorder.jpa.controller.OrderController;
import com.foodorder.jpa.entity.Address;
import com.foodorder.jpa.entity.Customer;
import com.foodorder.jpa.entity.DeliveryBoy;
import com.foodorder.jpa.entity.DeliveryBoyAddress;
import com.foodorder.jpa.entity.FoodItem;
import com.foodorder.jpa.entity.Order;
import com.foodorder.jpa.entity.OrderFoodItem;

public class FoodOrderApp 
{
	Scanner sc = null;
	Customer cust = null;
	List<Address> addrList = null;
	DeliveryBoy dboy = null;
	DeliveryBoyAddress dbadd = null;
	FoodItem fItem = null;
	List<OrderFoodItem> fooditem=null;
	public FoodOrderApp()
	{	
		sc = new Scanner(System.in);
		cust = new Customer();
		addrList = new ArrayList<Address>();
		dboy = new DeliveryBoy();
		dbadd = new DeliveryBoyAddress();
		fItem = new FoodItem();
		fooditem=new ArrayList<OrderFoodItem>();
	}
	public Customer getCustomerPersonalDetails()
	{
		System.out.println("Customer Name:");
		String cname = sc.next();
		System.out.println("Customer Phone:");
		String cphone = sc.next();
		System.out.println("Customer Email:");
		String cemail = sc.next();
		System.out.println("Customer User Id:");
		String cuserid = sc.next();
		System.out.println("Customer Password:");
		String cpwd = sc.next();
		cust.setcName(cname);
		cust.setcPhone(cphone);
		cust.setcEmail(cemail);
		cust.setcUserName(cname);
		cust.setcUserName(cuserid);
		cust.setcPassword(cpwd);
		return cust;
	}
	public List<Address> getCustomerAddressDetails()
	{
		String ch="y";
		int i=1;
		do
		{
			System.out.println("Address "+i);
			System.out.println("House No:");
			String chno = sc.next();
			System.out.println("Area:");
			String carea = sc.next();
			System.out.println("City:");
			String ccity = sc.next();
			Address addr = new Address(chno,carea,ccity);
			addrList.add(addr);
			System.out.println("Do you want to continue:");
			ch=sc.next();
			i++;
		}
		while(ch.equals("y"));
		return addrList;
	}
	public DeliveryBoy getDeliveryBoyPersonalDetails()
	{
		System.out.println("DeliveryBoy Name:");
		String dname = sc.next();
		System.out.println("Delivery Boy Phone:");
		String dphone = sc.next();
		System.out.println("Delivery Boy Email:");
		String demail = sc.next();
		System.out.println("Delivery Boy User Name ");
		String dUserName= sc.next();
		System.out.println("Delivery Boy Password");
		String dPassword = sc.next();
		dboy.setdName(dname);
		dboy.setdPhone(dphone);
		dboy.setdEmail(demail);
		dboy.setdUserName(dUserName);
		dboy.setdPassword(dPassword);
		dboy.setdAdd(dbadd);
		return dboy;
	}
	public DeliveryBoyAddress getDeliveryBoyAddressDetails()
	{
		System.out.println("Address: ");
		System.out.println("House No:");
		String dhno = sc.next();
		System.out.println("Area:");
		String darea = sc.next();
		System.out.println("City:");
		String dcity = sc.next();
		dbadd.setHouseNo(dhno);
		dbadd.setArea(darea);
		dbadd.setCity(dcity);
		return dbadd;
	}
	public FoodItem inputFoodItems() {
		int x=20;
		System.out.println("Enter Item Name:");
		String iName = sc.next();
		System.out.println("Enter Item Price:");
		Long iPrice = sc.nextLong();
		fItem.setItemName(iName);
		fItem.setItemPrice(iPrice);
		fItem.setItemUnit(x);
		return fItem;
	}
	public List<OrderFoodItem> getOrderFoodItemDetails()
	{
		String ch="y";
		int i=1;
		do
		{
			System.out.println("Enter Item Id:");
			Long itemId = sc.nextLong();
			System.out.println("Enter Item Quantity:");
			int itemQty = sc.nextInt();
			OrderFoodItem fditem = new OrderFoodItem(itemId, itemQty);
			fooditem.add(fditem);
			System.out.println("Do you want to continue:");
			ch=sc.next();
			i++;
		}
		while(ch.equals("y"));
		return fooditem;
	}
	
	public static void main(String[] args) 
	{
		FoodOrderApp app = new FoodOrderApp();
		CustomerController custController = new CustomerController();
		DeliveryController dboyController = new DeliveryController();
		FoodItemController fitemController  = new FoodItemController();
		OrderController ofController = new OrderController();
		Scanner sc = new Scanner(System.in);
		String choice ="Y";
		do {
			System.out.println("1.Admin");
			System.out.println("2.Customer");
			System.out.println("3.Delivery Boy");
			System.out.println("Select your choice:");
			int opt=sc.nextInt();		
			if (opt==1) {
				System.out.println("Admin Id:");
				String aid=sc.next();
				System.out.println("Admin password:");
				String apwd=sc.next();
				if (aid.equals("Admin") && (apwd.equals("Admin"))) {
					System.out.println("1.Order Approval");
					System.out.println("2.Assign to Delivery Boy");
					System.out.println("3.Add Food Items");
					System.out.println("Select your choice");
					int ch=sc.nextInt();
					if(ch==1) {

					}
					else if(ch==2) {	
					}
					else if(ch==3) {
						System.out.println("Add Food Items:");
						FoodItem fItem=app.inputFoodItems();	;
						fitemController.inputFoodItems(fItem);
						System.out.println("New Recipe Added");		
					}
					else {
						System.out.println("Invalid Credential,Try Again");
					}
				}
			}
			else if(opt==2) {
				System.out.println("1.New Customer Registration");
				System.out.println("2.Customer Login");
				System.out.println("Select your option:");
				int ch=sc.nextInt();
				if(ch==1) {
					Customer cust = app.getCustomerPersonalDetails();
					List<Address> addrList = app.getCustomerAddressDetails();
					System.out.println(cust.getcName()+" "+custController.registerNewCustomer(cust, addrList));
				}
				else if(ch==2) {
					System.out.println("Customer Id:");
					String uid = sc.next();
					System.out.println("Customer Password");
					String upwd=sc.next();
					String originalPassword=custController.getCustomerPassword(uid, upwd);
					if(upwd.equals(originalPassword)) {
						System.out.println("1.Order Food");
						System.out.println("2.Bill Payment");
						System.out.println("3.Change Password");
						System.out.println("Select your choice");
					}

					int ch1=sc.nextInt();
					if(ch1==1) {
						List<FoodItem> fItem = fitemController.getFoodRecipeDetails();
						System.out.println("Available Recipes:");
						System.out.println("FoodItem Id--FoodItem Name--FoodItem Price");
						for(FoodItem fo : fItem)
						{
							System.out.println(fo.getItemId()+"--"+fo.getItemName()+"--"+fo.getItemPrice());
						}
						DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
						Date d = Calendar.getInstance().getTime();
						String todaysdate = dateFormat.format(d);
						Order ord = new Order();
						ord.setOrdDate(todaysdate);
						ord.setCustId(uid);
						ord.setOrdPmntStatus("No");
						ord.setOrdStatus("order for approval");
						ord.setOrddbId(null);
						List<OrderFoodItem> foodList = app.getOrderFoodItemDetails();
						System.out.println(ofController.getOrderFood(ord, foodList));	
					}
					else if (ch1==2) {

					}
					else if (ch1==3) {

					}
				}
				else {
					System.out.println("Login Failed");
				}


			}

			else if(opt==3) 
			{
				System.out.println("1.New Delivery Boy Registration");
				System.out.println("2.Delivery Boy Login");
				System.out.println("Select your choice:");
				int ch3=sc.nextInt();
				if(ch3==1) {
					DeliveryBoy dboy = app.getDeliveryBoyPersonalDetails();
					DeliveryBoyAddress dbadd =app.getDeliveryBoyAddressDetails();
					System.out.println(dboy.getdName()+" "+dboyController.registerNewDeliveryBoy(dboy));
				}			
				else if(ch3==2)
				{
					System.out.println("User Id:");
					String uid = sc.next();
					System.out.println("User Password");
					String upwd=sc.next();
					String originalPassword=dboyController.getDeliveryBoyPassword(uid, upwd);
					if(upwd.equals(originalPassword)) {
						System.out.println("1.Order Delivery Status");
						System.out.println("Select Choice");
					}
					else {
						System.out.println("Login Failed");
					}
				}
			}
			System.out.println("Do you  want to continue:(y/n)");
			choice= sc.next();
		}

		while(choice.equals("y"));
	}
}
