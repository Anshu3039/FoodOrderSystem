package com.foodorder.jpa.service;

import com.foodorder.jpa.entity.DeliveryBoy;

public interface DeliveryService {
	public void registerDeliveryBoy(DeliveryBoy d);
	public String getDeliveryBoyPassword(String dUserName , String dPassword);
}
