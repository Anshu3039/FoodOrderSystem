package com.foodorder.jpa.service;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.foodorder.jpa.config.AppConfig;
import com.foodorder.jpa.entity.DeliveryBoy;

public class DeliveryServiceImpl implements DeliveryService {
	EntityManager em = null;
	public DeliveryServiceImpl() {
		em = AppConfig.getObject().getEntityManager(); 
	}
	@Override
	public void registerDeliveryBoy(DeliveryBoy d) {
		em.getTransaction().begin();
		em.persist(d);
		em.getTransaction().commit();
	}
	@Override
	public String getDeliveryBoyPassword(String dUserName, String dPassword) {
		Query q = em.createQuery("select d from DeliveryBoy d where d.dUserName ='"+dUserName+"'");
		Object o = q.getSingleResult();
		DeliveryBoy d = (DeliveryBoy)o;
		return d.getdPassword();
	}
}

