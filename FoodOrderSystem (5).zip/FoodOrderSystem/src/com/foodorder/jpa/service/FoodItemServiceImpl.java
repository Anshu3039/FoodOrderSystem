package com.foodorder.jpa.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import com.foodorder.jpa.config.AppConfig;
import com.foodorder.jpa.entity.FoodItem;

public class FoodItemServiceImpl implements FoodItemService {
	EntityManager em = null;
	public FoodItemServiceImpl() {
		em = AppConfig.getObject().getEntityManager(); 
	}

	@Override
	public FoodItem addFoodItems(FoodItem f) {
		em.getTransaction().begin();
		em.persist(f);
		em.getTransaction().commit();
		return f;
	
	}

	public List<FoodItem> getFoodRecipeList() {
		
			Query q = em.createQuery("select f from FoodItem f");
			List<FoodItem> l =q.getResultList();
			Iterator<FoodItem> i=l.iterator();
			List<FoodItem> al= new ArrayList<FoodItem>();
			while(i.hasNext()) {
				FoodItem f =i.next();
				al.add(f);
			}
			return al;

}
}