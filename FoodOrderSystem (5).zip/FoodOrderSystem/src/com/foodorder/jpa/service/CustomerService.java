package com.foodorder.jpa.service;


import java.util.List;

import com.foodorder.jpa.entity.Address;
import com.foodorder.jpa.entity.Customer;

public interface CustomerService {
	public void registerCustomer(Customer cust,List<Address> addrList);
	public String getCustomerPassword(String cUserName , String cPassword);
}

