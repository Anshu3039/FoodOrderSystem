package com.foodorder.jpa.service;

import java.util.List;
import com.foodorder.jpa.entity.FoodItem;

public interface FoodItemService {
 public FoodItem addFoodItems(FoodItem f);
 public List<FoodItem> getFoodRecipeList();
}
