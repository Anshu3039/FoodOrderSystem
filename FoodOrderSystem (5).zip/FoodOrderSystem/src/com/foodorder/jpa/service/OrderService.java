package com.foodorder.jpa.service;

import java.util.List;
import com.foodorder.jpa.entity.Order;
import com.foodorder.jpa.entity.OrderFoodItem;

public interface OrderService {
	public int getOrderFood(Order ord ,List<OrderFoodItem> foodList);
	public List<Order> getFoodOrderRequestList();
}
