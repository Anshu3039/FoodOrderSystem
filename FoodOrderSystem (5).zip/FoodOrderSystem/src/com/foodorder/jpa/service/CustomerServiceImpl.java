package com.foodorder.jpa.service;




import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.foodorder.jpa.config.AppConfig;
import com.foodorder.jpa.entity.Address;
import com.foodorder.jpa.entity.Customer;



public class CustomerServiceImpl implements CustomerService
{
	EntityManager em = null;
	public CustomerServiceImpl() {
		em = AppConfig.getObject().getEntityManager(); 
	}

	@Override
	public void registerCustomer(Customer cust, List<Address> addrList) {
		em.getTransaction().begin();
		for(Address address: addrList)
		{
			em.persist(address);
		}
		cust.setAddresses(addrList);
		em.persist(cust);
		em.getTransaction().commit();	
	}

	@Override
	public String getCustomerPassword(String cUserName , String cPassword) {
		Query q = em.createQuery("select c from Customer c where c.cUserName ='"+cUserName+"'");
		Object o = q.getSingleResult();
		Customer c = (Customer)o;
		return c.getcPassword();
	}

	
}
