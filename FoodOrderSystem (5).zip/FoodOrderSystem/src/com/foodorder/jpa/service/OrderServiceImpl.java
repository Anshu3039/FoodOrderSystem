package com.foodorder.jpa.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.foodorder.jpa.config.AppConfig;
import com.foodorder.jpa.entity.Address;
import com.foodorder.jpa.entity.Order;
import com.foodorder.jpa.entity.OrderFoodItem;

public class OrderServiceImpl implements OrderService{
	EntityManager em = null;
	public OrderServiceImpl()  {
		em =AppConfig.getObject().getEntityManager();
	}
	
	@Override
	public List<Order> getFoodOrderRequestList() {
		Query q = em.createQuery("select o from OrderFood o");
		List<Order> l =q.getResultList();
		Iterator<Order> i=l.iterator();
		List<Order> al= new ArrayList<Order>();
		while(i.hasNext()) {
			Order o =i.next();
			al.add(o);
		}
		return al;
	}

	@Override
	public int getOrderFood(Order ord, List<OrderFoodItem> foodList) {
		em.getTransaction().begin();
		int total_bill=0;
		for(OrderFoodItem fItem:foodList) {
			Query q=em.createQuery("select f.itemPrice from FoodItem f where f.itemId="+fItem.getItemId());
			Long price = (Long)q.getSingleResult();
			total_bill += price*fItem.getItemQty();
			em.persist(fItem);
		}
		ord.setOrdTotalBill(total_bill);
		ord.setOrdFoodItem(foodList);
		em.persist(ord);
		em.getTransaction().commit();	
		return total_bill;
		
	}

}



