package com.foodorder.jpa.config;

	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.Persistence;

	public class AppConfig {
		private static AppConfig instance=null;
		private AppConfig()
		{
		}
		public static AppConfig getObject()
		{
			if(instance==null)
			{
				instance=new AppConfig();
			}
			return instance;
		}
		public EntityManager getEntityManager() {
			EntityManagerFactory emc = Persistence.createEntityManagerFactory("Food_details");
			EntityManager em=emc.createEntityManager();
			return em;
		}

	}


