package com.foodorder.jpa.controller;

import com.foodorder.jpa.entity.DeliveryBoy;
import com.foodorder.jpa.service.DeliveryServiceImpl;

public class DeliveryController {
	DeliveryServiceImpl dboyService=null;
	public DeliveryController() 
	{
		dboyService=new DeliveryServiceImpl();
	}
	public  String registerNewDeliveryBoy(DeliveryBoy d) {
		dboyService.registerDeliveryBoy(d);
		return "Delivery Boy Registered Successfully";
	}
	public String getDeliveryBoyPassword(String dUserName, String dPassword) {
		return dboyService.getDeliveryBoyPassword(dUserName, dPassword);
	}
}
