package com.foodorder.jpa.controller;

import java.util.List;
import com.foodorder.jpa.entity.Order;
import com.foodorder.jpa.entity.OrderFoodItem;
import com.foodorder.jpa.service.OrderServiceImpl;

public class OrderController {
	OrderServiceImpl ofService = null;
	public OrderController() {
		ofService = new OrderServiceImpl();
	}
	public String getOrderFood(Order ord, List<OrderFoodItem> foodList) 
	{
		ofService.getOrderFood(ord, foodList);
		return "Food Ordered Successfully";
	}
	public List<Order> FoodOrderRequestList(){
		List<Order> li = ofService.getFoodOrderRequestList();
		return li;
	}
}
