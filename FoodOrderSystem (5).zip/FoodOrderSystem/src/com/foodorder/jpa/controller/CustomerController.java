package com.foodorder.jpa.controller;



import java.util.List;

import com.foodorder.jpa.entity.Address;
import com.foodorder.jpa.entity.Customer;
import com.foodorder.jpa.entity.DeliveryBoy;
import com.foodorder.jpa.service.CustomerServiceImpl;



public class CustomerController 
{
	CustomerServiceImpl custService=null;
	public CustomerController() 
	{
		custService=new CustomerServiceImpl();
	}
	
	public String registerNewCustomer(Customer cust, List<Address> addrList) 
	{
		custService.registerCustomer(cust, addrList);
		return "Customer Registered Successfully";
	}
	
	public String getCustomerPassword(String cUserName, String cPassword) {
		return custService.getCustomerPassword(cUserName, cPassword);
	}
	
}



