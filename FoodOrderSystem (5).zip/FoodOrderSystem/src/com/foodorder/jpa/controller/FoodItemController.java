package com.foodorder.jpa.controller;
import java.util.List;


import com.foodorder.jpa.entity.FoodItem;
import com.foodorder.jpa.service.FoodItemServiceImpl;

public class FoodItemController {
	FoodItemServiceImpl fService = null;
	public FoodItemController() {
		fService = new FoodItemServiceImpl();
	}
	public void inputFoodItems(FoodItem f) {
		fService.addFoodItems(f);
	}
	public List<FoodItem> getFoodRecipeDetails() {
		List<FoodItem> li = fService.getFoodRecipeList();
		return li;
	}
}
